"# Facial_Recognition_Based_Attendance_System" 

1) Install python
2) Go to current working directory in terminal
3) pip install -r requirements.txt
4) Enter names of students in the variables.py file
5) Go to the dataset folder and delete old dataset
4) run file 1 to get images by entering id of the students, repeat for the number of students, in the list that you entered in variables file
5) run file 2 for training
6) run file 3 for detection
7) attendance will be saved in the folder in excel sheet.